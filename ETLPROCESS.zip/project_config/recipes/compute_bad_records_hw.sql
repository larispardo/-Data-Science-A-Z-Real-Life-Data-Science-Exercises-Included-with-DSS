SELECT *
  FROM "ETLPROCESS_fakenamesuk_hw"
    where
    (
      "BloodType" is null or 
      "Kilograms" is null or
      "Centimeters" is null or
      "col_18" is not null or
      "col_19" is not null
    )