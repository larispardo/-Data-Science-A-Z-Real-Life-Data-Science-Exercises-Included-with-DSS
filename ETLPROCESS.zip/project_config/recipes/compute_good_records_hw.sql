SELECT *
  FROM "ETLPROCESS_fakenamesuk_hw"
    where
    (
      "BloodType" is not null and
      "Kilograms" is not null and
      "Centimeters" is not null and
      "col_18" is null and
      "col_19" is null
    )